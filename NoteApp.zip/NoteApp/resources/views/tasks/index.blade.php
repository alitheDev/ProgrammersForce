<!DOCTYPE html>
<html>
<head>
    <title>Task Manager</title>
    <style>
    /* Add your CSS styling here */
    .forecast-card {
      border: 1px solid #ccc;
      padding: 10px;
      margin-bottom: 10px;
    }
    .temperature {
      font-size: 24px;
      font-weight: bold;
    }
    .description {
      color: #888;
    }
  </style>
    


</head>
<body>
    <h1><center>Blogging Platform</center></h1>









    @if(session('success'))
        <div>{{ session('success') }}</div>
   @endif

 


<a style="display: inline-block;
  padding: 10px 20px;
  background-color: #3498db;
  color: #fff;
  text-decoration: none;
  border-radius: 4px;
" href="{{ route('tasks.create') }}">Create New Note</a>



    <ul>
        @foreach($tasks as $task)



            <div style="border:1px solid;">

            <br>    

         

           <h1 style="border: 1px solid; background-color:lightgreen;"> &nbsp; ✎ 
           <a href="{{ route('tasks.show', $task) }}">{{ $task->title }}</a> </h1>
           <br>
           {{ $task->description }}   <a href="{{ route('tasks.show', $task) }}"> Know More. </a> 
           
           <br>
<br><br>
            
                <a style="display: inline-block;  padding: 8px 16px;  background-color: orange;   color: white;   border: none;
  text-align: center;
  text-decoration: none;
  font-size: 14px;
  cursor: pointer;
  border-radius: 4px;"  href="{{ route('tasks.edit', $task) }}">Edit</a>



                <form action="{{ route('tasks.destroy', $task) }}" method="POST" style="display:inline">
                    @csrf
                    @method('DELETE')
                    <button 
                    
                    style="display: inline-block;  padding: 8px 16px;  background-color: red;   color: white;   border: none;
  text-align: center;
  text-decoration: none;
  font-size: 14px;
  cursor: pointer;
  border-radius: 4px;" 
                    
                    type="submit">
                        
                    Delete



                    </button>
</div>
<br>
<br> 
        @endforeach
    </ul>


</body>
</html>
