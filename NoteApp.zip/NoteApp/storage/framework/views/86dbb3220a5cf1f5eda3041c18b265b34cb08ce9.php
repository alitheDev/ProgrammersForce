<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($task->title); ?></title>
</head>
<body>
    <h1>Task Number: <?php echo e($task->id); ?></h1>
    <h2><?php echo e($task->title); ?></h2>
    <p><?php echo e($task->description); ?></p>

    <a href="<?php echo e(route('tasks.edit', $task)); ?>">Edit</a>
    <form action="<?php echo e(route('tasks.destroy', $task)); ?>" method="POST" style="display:inline"> 
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
       
        <button type="submit">Delete </button> 
    
    </form>



    




</body>
</html>
<?php /**PATH C:\Users\Ali\Desktop\Laravel\SmallProjects\1\Task App CRUD\crud-app\resources\views/tasks/show.blade.php ENDPATH**/ ?>