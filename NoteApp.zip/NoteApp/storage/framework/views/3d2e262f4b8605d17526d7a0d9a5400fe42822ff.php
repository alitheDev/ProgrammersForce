<!DOCTYPE html>
<html>
<head>
    <title>Task Manager</title>
    <style>
    /* Add your CSS styling here */
    .forecast-card {
      border: 1px solid #ccc;
      padding: 10px;
      margin-bottom: 10px;
    }
    .temperature {
      font-size: 24px;
      font-weight: bold;
    }
    .description {
      color: #888;
    }
  </style>
    


</head>
<body>
    <h1><center>Blogging Platform</center></h1>









    <?php if(session('success')): ?>
        <div><?php echo e(session('success')); ?></div>
   <?php endif; ?>

 


<a style="display: inline-block;
  padding: 10px 20px;
  background-color: #3498db;
  color: #fff;
  text-decoration: none;
  border-radius: 4px;
" href="<?php echo e(route('tasks.create')); ?>">Create New Note</a>



    <ul>
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



            <div style="border:1px solid;">

            <br>    

         

           <h1 style="border: 1px solid; background-color:lightgreen;"> &nbsp; ✎ 
           <a href="<?php echo e(route('tasks.show', $task)); ?>"><?php echo e($task->title); ?></a> </h1>
           <br>
           <?php echo e($task->description); ?>   <a href="<?php echo e(route('tasks.show', $task)); ?>"> Know More. </a> 
           
           <br>
<br><br>
            
                <a style="display: inline-block;  padding: 8px 16px;  background-color: orange;   color: white;   border: none;
  text-align: center;
  text-decoration: none;
  font-size: 14px;
  cursor: pointer;
  border-radius: 4px;"  href="<?php echo e(route('tasks.edit', $task)); ?>">Edit</a>



                <form action="<?php echo e(route('tasks.destroy', $task)); ?>" method="POST" style="display:inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button 
                    
                    style="display: inline-block;  padding: 8px 16px;  background-color: red;   color: white;   border: none;
  text-align: center;
  text-decoration: none;
  font-size: 14px;
  cursor: pointer;
  border-radius: 4px;" 
                    
                    type="submit">
                        
                    Delete



                    </button>
</div>
<br>
<br> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>


</body>
</html>
<?php /**PATH C:\Users\Ali\Desktop\Laravel\SmallProjects\1\Task App CRUD-Blog\crud-app\resources\views/tasks/index.blade.php ENDPATH**/ ?>