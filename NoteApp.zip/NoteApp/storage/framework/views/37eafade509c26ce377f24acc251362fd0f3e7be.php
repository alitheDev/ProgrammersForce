<!DOCTYPE html>
<html>
<head>
    <title>Edit Task</title>
</head>
<body>
    <h1>Edit Task</h1>

    <?php if($errors->any()): ?>
        <div>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('tasks.update', $task)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div>
            <label for="title">Title:</label>
            <input type="text" name="title" id="title" value="<?php echo e($task->title); ?>">
        </div>
        <div>
            <label for="description">Description:</label>
            <textarea name="description" id="description"><?php echo e($task->description); ?></textarea>
        </div>
        <button type="submit">Update</button>
    </form>
</body>
</html>
<?php /**PATH C:\Users\Ali\Desktop\Laravel\SmallProjects\1\Task App CRUD\crud-app\resources\views/tasks/edit.blade.php ENDPATH**/ ?>